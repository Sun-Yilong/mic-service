package com.imooc.ad.exception;

/**
 * Created by Yilong.
 */
public class AdException extends Exception {

    public AdException(String message) {
        super(message);
    }
}
