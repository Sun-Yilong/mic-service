package com.imooc.ad.search.vo.feature;

/**
 * Created by Yilong.
 */
public enum FeatureRelation {

    OR,
    AND
}
