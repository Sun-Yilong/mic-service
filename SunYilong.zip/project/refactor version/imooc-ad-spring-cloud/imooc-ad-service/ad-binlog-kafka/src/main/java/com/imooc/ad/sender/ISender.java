package com.imooc.ad.sender;

import com.imooc.ad.dto.MySqlRowData;

/**
 * Created by Yilong.
 */
public interface ISender {

    void sender(MySqlRowData rowData);
}
